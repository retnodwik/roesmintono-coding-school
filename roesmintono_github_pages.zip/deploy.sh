#!/bin/bash
# Simple deploy script using git + gh (GitHub CLI)
# Make sure git and gh are installed and gh is authenticated (gh auth login)

REPO_NAME="roesmintono-coding-school"

git init
git add .
git commit -m "Initial commit - website"
gh repo create "$REPO_NAME" --public --source=. --remote=origin --push
gh pages enable --branch main --path /
echo "Done. Open https://$(gh api user --jq .login).github.io/$REPO_NAME/"
