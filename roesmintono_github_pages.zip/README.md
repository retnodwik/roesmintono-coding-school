# Roesmintono Coding School - GitHub Pages Ready

Ini adalah paket siap-upload untuk membuat website statis menggunakan **GitHub Pages**.

## Cara cepat (menggunakan GitHub web UI)
1. Buka https://github.com dan login.
2. Buat repository baru dengan nama `roesmintono-coding-school` (public).
3. Pilih **Add file → Upload files** lalu upload semua file dari folder ini (index.html dan README.md).
4. Commit changes.
5. Masuk **Settings → Pages**, pilih branch `main` dan folder `/ (root)`, lalu save.
6. Tunggu beberapa detik — website akan tersedia di:
   `https://<username>.github.io/roesmintono-coding-school/`

## Cara cepat (menggunakan terminal dan GitHub CLI `gh`)
Pastikan `git` dan `gh` sudah terinstall dan kamu sudah login (`gh auth login`).

```bash
cd path/to/roesmintono_github_pages
git init
git add .
git commit -m "Initial commit - add website"
gh repo create roesmintono-coding-school --public --source=. --remote=origin --push
gh pages enable --branch main --path /
```

Setelah itu buka:
`https://<username>.github.io/roesmintono-coding-school/`

## Catatan
- File utama sudah dinamai `index.html` agar URL lebih bersih (tanpa menyertakan nama file).
- Jika ingin domain custom, tambahkan file `CNAME` berisi domainmu dan atur DNS A/CNAME sesuai panduan GitHub Pages.

Semoga membantu! Jika mau, saya bisa:
- Membuat file ZIP untuk diunduh.
- Membuat file `CNAME` untuk domain custom.
- Mengoptimalkan gambar / performa.
